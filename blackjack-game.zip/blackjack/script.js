/* =========================================================
   Royal Blackjack — Game Logic
   A learning-friendly implementation.

   Sections:
     1. Variables / state
     2. Sound helpers
     3. Deck creation & shuffle
     4. Card dealing & rendering
     5. Hand value calculation
     6. Betting system
     7. Player actions (hit/stand/double)
     8. Dealer logic / AI
     9. Round resolution & payouts
    10. UI updates
    11. Stats panel
    12. Event listeners / startup
   ========================================================= */


/* ---------- 1. Variables / state ---------- */

// Bankroll the player starts with
let bankroll = 1000;
let currentBet = 0;

// Deck and hands
let deck = [];
let playerHand = [];
let dealerHand = [];

// Game state flags
let roundInProgress = false;   // true between Deal and round end
let playerTurnOver = false;
let busyAnimating = false;     // prevents button spam
let canDouble = false;

// Statistics tracked across the session
let stats = {
  hands: 0,
  wins: 0,
  losses: 0,
  pushes: 0,
  biggestWin: 0
};

// Sound on/off
let soundOn = true;

// Card suits and ranks
const SUITS = ["♠", "♥", "♦", "♣"];
const RANKS = ["A", "2", "3", "4", "5", "6", "7", "8", "9", "10", "J", "Q", "K"];

// DOM references (filled in on load)
const $ = (id) => document.getElementById(id);


/* ---------- 2. Sound helpers ---------- */
// We use the WebAudio API to make little sounds without external files.

let audioCtx = null;
function ensureAudio() {
  if (!audioCtx) {
    try { audioCtx = new (window.AudioContext || window.webkitAudioContext)(); }
    catch (e) { audioCtx = null; }
  }
}

function playTone(freq, duration, type) {
  if (!soundOn) return;
  ensureAudio();
  if (!audioCtx) return;
  const osc = audioCtx.createOscillator();
  const gain = audioCtx.createGain();
  osc.type = type || "sine";
  osc.frequency.value = freq;
  gain.gain.value = 0.06;
  osc.connect(gain).connect(audioCtx.destination);
  osc.start();
  gain.gain.exponentialRampToValueAtTime(0.0001, audioCtx.currentTime + duration);
  osc.stop(audioCtx.currentTime + duration);
}

function soundDeal()  { playTone(420, 0.08, "square"); }
function soundChip()  { playTone(900, 0.05, "triangle"); setTimeout(() => playTone(600, 0.05, "triangle"), 60); }
function soundClick() { playTone(300, 0.04, "square"); }
function soundWin()   { [523, 659, 784, 1046].forEach((f,i) => setTimeout(() => playTone(f, 0.18, "triangle"), i*100)); }
function soundLose()  { [400, 300, 200].forEach((f,i) => setTimeout(() => playTone(f, 0.22, "sawtooth"), i*140)); }


/* ---------- 3. Deck creation & shuffle ---------- */

// Build a fresh 52-card deck (we'll use one deck and reshuffle when low).
function buildDeck() {
  const cards = [];
  for (let s = 0; s < SUITS.length; s++) {
    for (let r = 0; r < RANKS.length; r++) {
      cards.push({ suit: SUITS[s], rank: RANKS[r] });
    }
  }
  return cards;
}

// Fisher-Yates shuffle. Simple and fair.
function shuffle(cards) {
  for (let i = cards.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1));
    const temp = cards[i];
    cards[i] = cards[j];
    cards[j] = temp;
  }
  return cards;
}

function resetDeckIfLow() {
  // If less than 15 cards left, build a fresh shuffled deck.
  if (deck.length < 15) {
    deck = shuffle(buildDeck());
  }
}


/* ---------- 4. Card dealing & rendering ---------- */

// Draw a single card off the top of the deck.
function drawCard() {
  resetDeckIfLow();
  return deck.pop();
}

// Build the HTML element for a card (or its back).
function makeCardElement(card, faceDown) {
  const el = document.createElement("div");
  el.className = "card";
  if (faceDown) {
    el.classList.add("back");
    return el;
  }
  const isRed = card.suit === "♥" || card.suit === "♦";
  if (isRed) el.classList.add("red");

  const topCorner = document.createElement("div");
  topCorner.className = "corner";
  topCorner.innerHTML = `<span>${card.rank}</span><span>${card.suit}</span>`;

  const pip = document.createElement("div");
  pip.className = "pip";
  pip.textContent = card.suit;

  const botCorner = document.createElement("div");
  botCorner.className = "corner bottom";
  botCorner.innerHTML = `<span>${card.rank}</span><span>${card.suit}</span>`;

  el.appendChild(topCorner);
  el.appendChild(pip);
  el.appendChild(botCorner);
  return el;
}

// Add a card to a hand and render it, with a small delay for animation.
function dealCardTo(who, faceDown) {
  return new Promise((resolve) => {
    const card = drawCard();
    if (who === "player") playerHand.push(card);
    else dealerHand.push({ ...card, hidden: !!faceDown });

    const container = who === "player" ? $("playerCards") : $("dealerCards");
    const el = makeCardElement(card, faceDown);
    container.appendChild(el);
    soundDeal();

    setTimeout(() => {
      updateHandValues();
      resolve();
    }, 350);
  });
}

// Re-render dealer cards (used to flip the hidden card).
function renderDealerCards(revealAll) {
  const container = $("dealerCards");
  container.innerHTML = "";
  for (let i = 0; i < dealerHand.length; i++) {
    const c = dealerHand[i];
    const hidden = c.hidden && !revealAll;
    const el = makeCardElement(c, hidden);
    if (!hidden && c.hidden) {
      // This is the flip reveal
      el.classList.add("flipping");
      c.hidden = false;
    }
    container.appendChild(el);
  }
}


/* ---------- 5. Hand value calculation ---------- */

// Returns the best score considering aces.
function handValue(hand, ignoreHidden) {
  let total = 0;
  let aces = 0;
  for (let i = 0; i < hand.length; i++) {
    const c = hand[i];
    if (ignoreHidden && c.hidden) continue;
    if (c.rank === "A") {
      aces += 1;
      total += 11;
    } else if (c.rank === "K" || c.rank === "Q" || c.rank === "J") {
      total += 10;
    } else {
      total += parseInt(c.rank, 10);
    }
  }
  // Down-grade aces from 11 to 1 if we're over 21.
  while (total > 21 && aces > 0) {
    total -= 10;
    aces -= 1;
  }
  return total;
}

function isBlackjack(hand) {
  return hand.length === 2 && handValue(hand) === 21;
}


/* ---------- 6. Betting system ---------- */

function addToBet(amount) {
  if (roundInProgress) return;
  if (amount > bankroll) {
    flashBanner("Not enough!", "lose");
    return;
  }
  currentBet += amount;
  bankroll -= amount;
  soundChip();
  updateUI();
}

function clearBet() {
  if (roundInProgress) return;
  bankroll += currentBet;
  currentBet = 0;
  soundClick();
  updateUI();
}


/* ---------- 7. Player actions ---------- */

async function startDeal() {
  if (roundInProgress || busyAnimating) return;
  if (currentBet <= 0) {
    flashBanner("Place a bet first", "lose");
    return;
  }

  // Clear table from previous round
  $("playerCards").innerHTML = "";
  $("dealerCards").innerHTML = "";
  hideBanner();
  playerHand = [];
  dealerHand = [];
  playerTurnOver = false;
  roundInProgress = true;
  busyAnimating = true;
  resetDeckIfLow();

  // Deal in the traditional order: player, dealer, player, dealer(hole)
  await dealCardTo("player", false);
  await dealCardTo("dealer", false);
  await dealCardTo("player", false);
  await dealCardTo("dealer", true);

  // Double down is allowed only on the first two cards and if you can afford it
  canDouble = bankroll >= currentBet;

  busyAnimating = false;
  updateUI();

  // Check for immediate blackjack
  const playerBJ = isBlackjack(playerHand);
  const dealerBJ = isBlackjack(dealerHand);
  if (playerBJ || dealerBJ) {
    await endRound();
  }
}

async function playerHit() {
  if (!roundInProgress || playerTurnOver || busyAnimating) return;
  busyAnimating = true;
  canDouble = false;
  await dealCardTo("player", false);
  busyAnimating = false;

  const v = handValue(playerHand);
  if (v >= 21) {
    playerTurnOver = true;
    await endRound();
  }
  updateUI();
}

async function playerStand() {
  if (!roundInProgress || playerTurnOver || busyAnimating) return;
  playerTurnOver = true;
  updateUI();
  await dealerPlay();
  await endRound();
}

async function playerDouble() {
  if (!roundInProgress || playerTurnOver || busyAnimating) return;
  if (playerHand.length !== 2) return;
  if (bankroll < currentBet) return;

  busyAnimating = true;
  bankroll -= currentBet;
  currentBet *= 2;
  canDouble = false;
  soundChip();
  updateUI();

  await dealCardTo("player", false);
  playerTurnOver = true;
  busyAnimating = false;

  if (handValue(playerHand) > 21) {
    await endRound();
  } else {
    await dealerPlay();
    await endRound();
  }
}


/* ---------- 8. Dealer logic / AI ---------- */

async function dealerPlay() {
  busyAnimating = true;
  // Reveal hidden card with a small flip
  renderDealerCards(true);
  updateHandValues();
  await wait(550);

  // Hit on 16 or less, stand on 17 or more (stand on all 17s).
  while (handValue(dealerHand) < 17) {
    await dealCardTo("dealer", false);
    await wait(400);
  }
  busyAnimating = false;
}


/* ---------- 9. Round resolution & payouts ---------- */

async function endRound() {
  // Always make sure the dealer card is shown at the end
  for (let i = 0; i < dealerHand.length; i++) dealerHand[i].hidden = false;
  renderDealerCards(true);
  updateHandValues();

  const pv = handValue(playerHand);
  const dv = handValue(dealerHand);
  const playerBJ = isBlackjack(playerHand);
  const dealerBJ = isBlackjack(dealerHand);

  let result = "";    // "win" | "lose" | "push" | "blackjack"
  let payout = 0;     // amount to add to bankroll (includes original bet)
  let message = "";

  if (pv > 21) {
    result = "lose"; message = "Bust!"; payout = 0;
  } else if (playerBJ && !dealerBJ) {
    result = "blackjack"; message = "Blackjack!"; payout = currentBet + Math.floor(currentBet * 1.5);
  } else if (dealerBJ && !playerBJ) {
    result = "lose"; message = "Dealer Blackjack"; payout = 0;
  } else if (playerBJ && dealerBJ) {
    result = "push"; message = "Push"; payout = currentBet;
  } else if (dv > 21) {
    result = "win"; message = "Dealer Busts!"; payout = currentBet * 2;
  } else if (pv > dv) {
    result = "win"; message = "Player Wins"; payout = currentBet * 2;
  } else if (pv < dv) {
    result = "lose"; message = "Dealer Wins"; payout = 0;
  } else {
    result = "push"; message = "Push"; payout = currentBet;
  }

  // Apply payout
  const net = payout - currentBet;   // profit (or loss)
  bankroll += payout;

  // Stats
  stats.hands += 1;
  if (result === "win" || result === "blackjack") {
    stats.wins += 1;
    if (net > stats.biggestWin) stats.biggestWin = net;
  } else if (result === "lose") {
    stats.losses += 1;
  } else {
    stats.pushes += 1;
  }

  // Show banner & sounds
  const bannerClass = (result === "push") ? "push" :
                      (result === "lose") ? "lose" : "win";
  flashBanner(message, bannerClass);
  if (result === "win" || result === "blackjack") {
    soundWin();
    addWinGlow();
  } else if (result === "lose") {
    soundLose();
  }

  // Reset for next round
  currentBet = 0;
  roundInProgress = false;
  playerTurnOver = false;
  busyAnimating = false;
  canDouble = false;
  updateUI();

  // Out of money? Offer a top-up.
  if (bankroll <= 0) {
    await wait(1500);
    flashBanner("You're broke — here's $500", "win");
    bankroll = 500;
    updateUI();
  }
}

function addWinGlow() {
  const cards = document.querySelectorAll("#playerCards .card");
  cards.forEach(c => c.classList.add("win"));
}


/* ---------- 10. UI updates ---------- */

function updateUI() {
  $("bankrollDisplay").textContent = "$" + bankroll;
  $("betDisplay").textContent = "$" + currentBet;

  // Button enable/disable logic
  $("dealBtn").disabled    = roundInProgress || busyAnimating || currentBet <= 0;
  $("hitBtn").disabled     = !roundInProgress || playerTurnOver || busyAnimating;
  $("standBtn").disabled   = !roundInProgress || playerTurnOver || busyAnimating;
  $("doubleBtn").disabled  = !roundInProgress || playerTurnOver || busyAnimating || !canDouble;
  $("clearBtn").disabled   = roundInProgress || currentBet <= 0;
  $("newHandBtn").disabled = roundInProgress || busyAnimating;

  // Chips disabled while round is running
  document.querySelectorAll(".chip").forEach(c => {
    const val = parseInt(c.dataset.value, 10);
    c.disabled = roundInProgress || val > bankroll;
    c.style.opacity = c.disabled ? "0.4" : "1";
  });
}

function updateHandValues() {
  const pv = handValue(playerHand);
  $("playerValue").textContent = pv > 0 ? pv : "";

  // Dealer: hide value of hidden card until reveal
  const dv = handValue(dealerHand, true);
  $("dealerValue").textContent = dv > 0 ? dv : "";
}

function flashBanner(text, kind) {
  const b = $("statusBanner");
  b.className = "status-banner show";
  if (kind) b.classList.add(kind);
  b.textContent = text;
}

function hideBanner() {
  const b = $("statusBanner");
  b.className = "status-banner";
  b.textContent = "";
}


/* ---------- 11. Stats panel ---------- */

function openStats() {
  $("sHands").textContent    = stats.hands;
  $("sWins").textContent     = stats.wins;
  $("sLosses").textContent   = stats.losses;
  $("sPushes").textContent   = stats.pushes;
  $("sBiggest").textContent  = "$" + stats.biggestWin;
  $("sBankroll").textContent = "$" + bankroll;
  $("statsModal").classList.remove("hidden");
}

function closeStats() {
  $("statsModal").classList.add("hidden");
}


/* ---------- Small helper ---------- */
function wait(ms) {
  return new Promise(r => setTimeout(r, ms));
}


/* ---------- 12. Event listeners / startup ---------- */

window.addEventListener("load", () => {
  // Hide loading screen after ~1.6s for that "shuffle" feel
  setTimeout(() => {
    $("loadingScreen").classList.add("hidden");
  }, 1600);

  // Build & shuffle the deck once
  deck = shuffle(buildDeck());

  // Chip clicks
  document.querySelectorAll(".chip").forEach(chip => {
    chip.addEventListener("click", () => {
      const value = parseInt(chip.dataset.value, 10);
      addToBet(value);
      chip.classList.add("flying");
      setTimeout(() => chip.classList.remove("flying"), 500);
    });
  });

  // Buttons
  $("dealBtn").addEventListener("click", () => { soundClick(); startDeal(); });
  $("hitBtn").addEventListener("click", () => { soundClick(); playerHit(); });
  $("standBtn").addEventListener("click", () => { soundClick(); playerStand(); });
  $("doubleBtn").addEventListener("click", () => { soundClick(); playerDouble(); });
  $("clearBtn").addEventListener("click", () => { soundClick(); clearBet(); });
  $("newHandBtn").addEventListener("click", () => {
    if (roundInProgress) return;
    soundClick();
    $("playerCards").innerHTML = "";
    $("dealerCards").innerHTML = "";
    playerHand = [];
    dealerHand = [];
    hideBanner();
    updateHandValues();
    updateUI();
  });

  // Mute toggle
  $("muteBtn").addEventListener("click", () => {
    soundOn = !soundOn;
    $("muteBtn").textContent = soundOn ? "🔊" : "🔇";
  });

  // Stats modal
  $("statsBtn").addEventListener("click", openStats);
  $("closeStatsBtn").addEventListener("click", closeStats);

  updateUI();
});
